from page_loader.loader import download

__all__ = [download]
